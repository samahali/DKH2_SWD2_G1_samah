# Mock design of image bellow with simple css

![Screenshot of mocked design](./mock.jpeg)

### Using this feature only
* display: inline, inline-block;
* background
* hover
* text-shadow
* box-model